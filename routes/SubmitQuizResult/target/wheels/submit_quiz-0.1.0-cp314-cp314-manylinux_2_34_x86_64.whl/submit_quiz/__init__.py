from .submit_quiz import *

__doc__ = submit_quiz.__doc__
if hasattr(submit_quiz, "__all__"):
    __all__ = submit_quiz.__all__