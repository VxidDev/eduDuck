from .quiz_parser import *

__doc__ = quiz_parser.__doc__
if hasattr(quiz_parser, "__all__"):
    __all__ = quiz_parser.__all__